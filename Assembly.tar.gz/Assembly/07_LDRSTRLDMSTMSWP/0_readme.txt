# Load-Store instructions transfer data between memory and processor registers

LDR  Rd<-mem32[address]  #load word in register
STR  Rd->mem32[address]  #save word from register
