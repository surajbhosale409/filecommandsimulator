SWI instruction causes software interrupt.
Syntax
swi swi_number

MRS and MSR instructions transfter content of cpsr to and from other register
MRS  Rd=cpsr  #copy program status register to general purpose register
MSR  cpsr=Rm  #copy general purpose register to program status register

Co-processor instructions allow to do data processing, register transfer, memory transfer to and from coprocessor.
CDP - coprocessor data processing
MRC|MCR - coprocessor register transfer
LDC|STC - coprocessor blocks of memory transfer
