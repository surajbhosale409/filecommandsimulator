Multiply instructions multiply contents of pair of registers and store result in one or two registers depending on instruction.

Syntax
MUL{s} Rd, Rm, Rs, Rn

MUL  Rd=Rm*Rs

Syntax
MLA{s} Rd, Rm, Rs, Rn

MLA  Rd=(Rm*Rs)+Rn

Syntax
<instruction>{s} RdLo, RdHi, Rm, Rs

SMULL  [RdHi,RdLo]=Rm*Rs    #signed
UMULL  [RdHi,RdLo]=Rm*Rs    #unsigned
SMLAL  [RdHi,RdLo]=[RdHi,RdLo]+(Rm*Rs)
UMLAL  [RdHi,RdLo]=[RdHi,RdLo]+(Rm*Rs)
