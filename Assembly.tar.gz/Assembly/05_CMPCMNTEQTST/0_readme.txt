Comparision instructions are used to compare or test two 32-bit values. They update cpsr flag bits according to result. These set bits can be used to change program flow.

Syntax:
<instruction> Rn,N

CMP  Rn-N
CMN  Rn+N
TEQ  Rn^N
TST  Rn&N
