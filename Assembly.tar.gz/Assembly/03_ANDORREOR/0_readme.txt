Logical instruction perform bitwise logical operations

AND  Rd=Rn&N
ORR  Rd=Rn|N
EOR  Rd=Rn^N
BIC  Rd=Rn&~N
