Move instructions are data processing instructions.

Syntax
<instruction>{s} Rd,N   #'N' is immediate value or Register

MOV  Rd=N
MVN  Rd=~N
